import { MenuService } from '../menu.service';
import { prisma } from '../../database/client';
import { MenuItem, Prisma } from '@prisma/client';
import { cacheService, CacheInvalidator } from '../cache.service';

// Mock prisma client
jest.mock('../../database/client', () => ({
  prisma: {
    menuItem: {
      create: jest.fn(),
      findUnique: jest.fn(),
      findMany: jest.fn(),
      update: jest.fn(),
      updateMany: jest.fn(),
      delete: jest.fn(),
      count: jest.fn(),
      aggregate: jest.fn(),
    },
    vote: {
      updateMany: jest.fn(),
    },
    pollResult: {
      updateMany: jest.fn(),
    },
  },
}));

// Mock logger
jest.mock('../../utils/logger', () => ({
  logger: {
    info: jest.fn(),
    error: jest.fn(),
    warn: jest.fn(),
    debug: jest.fn(),
  },
}));

// Mock cache service
jest.mock('../cache.service', () => ({
  cacheService: {
    getOrSet: jest.fn(),
  },
  CacheInvalidator: {
    invalidateMenu: jest.fn(),
  },
  CACHE_KEYS: {
    MENU_ITEMS_ACTIVE: 'menu_items_active',
    MENU_ITEMS_BY_CATEGORY: (category: string) => `menu_items_category_${category}`,
  },
  CACHE_TTL: {
    MENU: 300,
  },
}));

// Helper function to create mock menu item
const createMockMenuItem = (overrides?: Partial<MenuItem>): MenuItem => ({
  id: 1,
  name: 'Test Dish',
  description: 'Test Description',
  price: 100,
  category: 'Main',
  imageUrl: 'https://example.com/image.jpg',
  isActive: true,
  createdBy: 1,
  createdAt: new Date(),
  updatedAt: new Date(),
  ...overrides,
});

describe('MenuService', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  describe('createMenuItem', () => {
    it('should create a new menu item successfully', async () => {
      const mockData = {
        name: 'Pizza',
        description: 'Delicious pizza',
        price: 500,
        category: 'Main',
        imageUrl: 'https://example.com/pizza.jpg',
        isActive: true,
        createdBy: 1,
      };

      const mockCreatedItem = createMockMenuItem(mockData);

      (prisma.menuItem.create as jest.Mock).mockResolvedValue(mockCreatedItem);

      const result = await MenuService.createMenuItem(mockData);

      expect(prisma.menuItem.create).toHaveBeenCalledWith({
        data: {
          name: mockData.name,
          description: mockData.description,
          price: mockData.price,
          category: mockData.category,
          imageUrl: mockData.imageUrl,
          isActive: mockData.isActive,
          createdBy: mockData.createdBy,
        },
      });

      expect(CacheInvalidator.invalidateMenu).toHaveBeenCalled();
      expect(result).toEqual(mockCreatedItem);
    });

    it('should create menu item with default isActive=true if not provided', async () => {
      const mockData = {
        name: 'Burger',
        createdBy: 1,
      };

      const mockCreatedItem = createMockMenuItem({ name: 'Burger', isActive: true });

      (prisma.menuItem.create as jest.Mock).mockResolvedValue(mockCreatedItem);

      await MenuService.createMenuItem(mockData);

      expect(prisma.menuItem.create).toHaveBeenCalledWith({
        data: expect.objectContaining({
          isActive: true,
        }),
      });
    });

    it('should throw an error if creation fails', async () => {
      const mockData = {
        name: 'Pizza',
        createdBy: 1,
      };

      (prisma.menuItem.create as jest.Mock).mockRejectedValue(new Error('DB Error'));

      await expect(MenuService.createMenuItem(mockData)).rejects.toThrow('Failed to create menu item');
    });
  });

  describe('getMenuItemById', () => {
    it('should return menu item if found', async () => {
      const mockItem = createMockMenuItem();

      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(mockItem);

      const result = await MenuService.getMenuItemById(1);

      expect(prisma.menuItem.findUnique).toHaveBeenCalledWith({
        where: { id: 1 },
      });

      expect(result).toEqual(mockItem);
    });

    it('should return null if menu item not found', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(null);

      const result = await MenuService.getMenuItemById(999);

      expect(result).toBeNull();
    });

    it('should throw an error if query fails', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockRejectedValue(new Error('DB Error'));

      await expect(MenuService.getMenuItemById(1)).rejects.toThrow('Failed to get menu item');
    });
  });

  describe('updateMenuItem', () => {
    it('should update menu item successfully', async () => {
      const mockUpdatedItem = createMockMenuItem({
        name: 'Updated Pizza',
        price: 600,
      });

      (prisma.menuItem.update as jest.Mock).mockResolvedValue(mockUpdatedItem);

      const result = await MenuService.updateMenuItem(1, {
        name: 'Updated Pizza',
        price: 600,
      });

      expect(prisma.menuItem.update).toHaveBeenCalledWith({
        where: { id: 1 },
        data: {
          name: 'Updated Pizza',
          price: 600,
          updatedAt: expect.any(Date),
        },
      });

      expect(CacheInvalidator.invalidateMenu).toHaveBeenCalled();
      expect(result).toEqual(mockUpdatedItem);
    });

    it('should throw error if menu item not found', async () => {
      const error = Object.assign(
        new Error('Record to update not found.'),
        {
          code: 'P2025',
          clientVersion: '5.6.0',
          meta: { cause: 'Record to update not found.' },
        }
      );
      Object.setPrototypeOf(error, Prisma.PrismaClientKnownRequestError.prototype);

      (prisma.menuItem.update as jest.Mock).mockRejectedValue(error);

      await expect(
        MenuService.updateMenuItem(999, { name: 'Test' })
      ).rejects.toThrow('Menu item not found');
    });
  });

  describe('deleteMenuItem', () => {
    it('should delete menu item without related data', async () => {
      const mockItem = {
        ...createMockMenuItem(),
        _count: {
          votes: 0,
          pollResults: 0,
        },
      };

      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(mockItem);
      (prisma.menuItem.delete as jest.Mock).mockResolvedValue(mockItem);

      await MenuService.deleteMenuItem(1);

      expect(prisma.menuItem.findUnique).toHaveBeenCalledWith({
        where: { id: 1 },
        include: {
          _count: {
            select: {
              votes: true,
              pollResults: true,
            },
          },
        },
      });

      expect(prisma.menuItem.delete).toHaveBeenCalledWith({
        where: { id: 1 },
      });

      expect(CacheInvalidator.invalidateMenu).toHaveBeenCalled();
    });

    it('should cleanup related data before deleting', async () => {
      const mockItem = {
        ...createMockMenuItem(),
        _count: {
          votes: 5,
          pollResults: 2,
        },
      };

      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(mockItem);
      (prisma.vote.updateMany as jest.Mock).mockResolvedValue({ count: 5 });
      (prisma.pollResult.updateMany as jest.Mock).mockResolvedValue({ count: 2 });
      (prisma.menuItem.delete as jest.Mock).mockResolvedValue(mockItem);

      await MenuService.deleteMenuItem(1);

      expect(prisma.vote.updateMany).toHaveBeenCalledWith({
        where: { menuItemId: 1 },
        data: { menuItemId: null },
      });

      expect(prisma.pollResult.updateMany).toHaveBeenCalledWith({
        where: { winnerMenuItemId: 1 },
        data: { winnerMenuItemId: null },
      });

      expect(prisma.menuItem.delete).toHaveBeenCalledWith({
        where: { id: 1 },
      });
    });

    it('should throw error if menu item not found', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(null);

      await expect(MenuService.deleteMenuItem(999)).rejects.toThrow('Menu item not found');
    });
  });

  describe('getAllMenuItems', () => {
    it('should return all menu items ordered by active status and name', async () => {
      const mockItems = [
        createMockMenuItem({ id: 1, name: 'Apple', isActive: true }),
        createMockMenuItem({ id: 2, name: 'Banana', isActive: true }),
        createMockMenuItem({ id: 3, name: 'Cherry', isActive: false }),
      ];

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockItems);

      const result = await MenuService.getAllMenuItems();

      expect(prisma.menuItem.findMany).toHaveBeenCalledWith({
        orderBy: [
          { isActive: 'desc' },
          { name: 'asc' },
        ],
      });

      expect(result).toEqual(mockItems);
    });
  });

  describe('getActiveMenuItems', () => {
    it('should return active menu items from cache or database', async () => {
      const mockActiveItems = [
        createMockMenuItem({ id: 1, name: 'Pizza', isActive: true }),
        createMockMenuItem({ id: 2, name: 'Burger', isActive: true }),
      ];

      (cacheService.getOrSet as jest.Mock).mockImplementation(async (key, fetchFn) => {
        return await fetchFn();
      });

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockActiveItems);

      const result = await MenuService.getActiveMenuItems();

      expect(cacheService.getOrSet).toHaveBeenCalled();
      expect(result).toEqual(mockActiveItems);
    });
  });

  describe('getMenuItemsByCategory', () => {
    it('should return menu items by category from cache or database', async () => {
      const category = 'Main';
      const mockItems = [
        createMockMenuItem({ id: 1, name: 'Pizza', category: 'Main' }),
        createMockMenuItem({ id: 2, name: 'Pasta', category: 'Main' }),
      ];

      (cacheService.getOrSet as jest.Mock).mockImplementation(async (key, fetchFn) => {
        return await fetchFn();
      });

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockItems);

      const result = await MenuService.getMenuItemsByCategory(category);

      expect(cacheService.getOrSet).toHaveBeenCalled();
      expect(result).toEqual(mockItems);
    });
  });

  describe('searchMenuItems', () => {
    it('should search menu items by name or description', async () => {
      const mockItems = [
        createMockMenuItem({ name: 'Cheese Pizza', description: 'Pizza with cheese' }),
        createMockMenuItem({ name: 'Pepperoni', description: 'Pizza with pepperoni' }),
      ];

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockItems);

      const result = await MenuService.searchMenuItems('pizza');

      expect(prisma.menuItem.findMany).toHaveBeenCalledWith({
        where: {
          OR: [
            { name: { contains: 'pizza' } },
            { description: { contains: 'pizza' } },
          ],
          isActive: true,
        },
        orderBy: { name: 'asc' },
      });

      expect(result).toEqual(mockItems);
    });
  });

  describe('toggleMenuItemStatus', () => {
    it('should toggle menu item status from active to inactive', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue({
        isActive: true,
      });

      const mockToggledItem = createMockMenuItem({ isActive: false });
      (prisma.menuItem.update as jest.Mock).mockResolvedValue(mockToggledItem);

      const result = await MenuService.toggleMenuItemStatus(1);

      expect(prisma.menuItem.update).toHaveBeenCalledWith({
        where: { id: 1 },
        data: {
          isActive: false,
          updatedAt: expect.any(Date),
        },
      });

      expect(CacheInvalidator.invalidateMenu).toHaveBeenCalled();
      expect(result.isActive).toBe(false);
    });

    it('should toggle menu item status from inactive to active', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue({
        isActive: false,
      });

      const mockToggledItem = createMockMenuItem({ isActive: true });
      (prisma.menuItem.update as jest.Mock).mockResolvedValue(mockToggledItem);

      const result = await MenuService.toggleMenuItemStatus(1);

      expect(result.isActive).toBe(true);
    });

    it('should throw error if menu item not found', async () => {
      (prisma.menuItem.findUnique as jest.Mock).mockResolvedValue(null);

      await expect(MenuService.toggleMenuItemStatus(999)).rejects.toThrow('Menu item not found');
    });
  });

  describe('getPopularMenuItems', () => {
    it('should return popular menu items with stats', async () => {
      const mockPopularItems = [
        {
          ...createMockMenuItem({ id: 1, name: 'Pizza' }),
          _count: {
            votes: 50,
            pollResults: 10,
          },
        },
        {
          ...createMockMenuItem({ id: 2, name: 'Burger' }),
          _count: {
            votes: 30,
            pollResults: 5,
          },
        },
      ];

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockPopularItems);

      const result = await MenuService.getPopularMenuItems(10);

      expect(prisma.menuItem.findMany).toHaveBeenCalledWith({
        where: { isActive: true },
        include: {
          _count: {
            select: {
              votes: true,
              pollResults: true,
            },
          },
        },
        orderBy: {
          votes: {
            _count: 'desc',
          },
        },
        take: 10,
      });

      expect(result[0]).toHaveProperty('voteCount', 50);
      expect(result[0]).toHaveProperty('winCount', 10);
      expect(result[1]).toHaveProperty('voteCount', 30);
      expect(result[1]).toHaveProperty('winCount', 5);
    });
  });

  describe('getCategories', () => {
    it('should return sorted list of categories', async () => {
      const mockCategories = [
        { category: 'Desserts' },
        { category: 'Main' },
        { category: 'Appetizers' },
      ];

      (cacheService.getOrSet as jest.Mock).mockImplementation(async (key, fetchFn) => {
        return await fetchFn();
      });

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue(mockCategories);

      const result = await MenuService.getCategories();

      expect(result).toEqual(['Appetizers', 'Desserts', 'Main']);
    });
  });

  describe('getMenuStats', () => {
    it('should return menu statistics', async () => {
      (prisma.menuItem.count as jest.Mock)
        .mockResolvedValueOnce(50) // total
        .mockResolvedValueOnce(40); // active

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue([
        { category: 'Main' },
        { category: 'Desserts' },
        { category: 'Appetizers' },
      ]);

      (prisma.menuItem.aggregate as jest.Mock).mockResolvedValue({
        _avg: {
          price: 350.5,
        },
      });

      const result = await MenuService.getMenuStats();

      expect(result).toEqual({
        total: 50,
        active: 40,
        categories: 3,
        averagePrice: 350.5,
      });
    });

    it('should handle null average price', async () => {
      (prisma.menuItem.count as jest.Mock)
        .mockResolvedValueOnce(10)
        .mockResolvedValueOnce(8);

      (prisma.menuItem.findMany as jest.Mock).mockResolvedValue([
        { category: 'Main' },
      ]);

      (prisma.menuItem.aggregate as jest.Mock).mockResolvedValue({
        _avg: {
          price: null,
        },
      });

      const result = await MenuService.getMenuStats();

      expect(result.averagePrice).toBe(0);
    });
  });

  describe('bulkUpdateStatus', () => {
    it('should bulk update menu items status', async () => {
      (prisma.menuItem.updateMany as jest.Mock).mockResolvedValue({
        count: 3,
      });

      const result = await MenuService.bulkUpdateStatus([1, 2, 3], false);

      expect(prisma.menuItem.updateMany).toHaveBeenCalledWith({
        where: {
          id: {
            in: [1, 2, 3],
          },
        },
        data: {
          isActive: false,
          updatedAt: expect.any(Date),
        },
      });

      expect(CacheInvalidator.invalidateMenu).toHaveBeenCalled();
      expect(result).toBe(3);
    });

    it('should return 0 if no items were updated', async () => {
      (prisma.menuItem.updateMany as jest.Mock).mockResolvedValue({
        count: 0,
      });

      const result = await MenuService.bulkUpdateStatus([999], true);

      expect(result).toBe(0);
    });
  });
});
