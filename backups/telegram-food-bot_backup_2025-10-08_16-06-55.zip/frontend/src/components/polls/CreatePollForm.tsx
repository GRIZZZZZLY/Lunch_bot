/**
 * CreatePollForm - Форма создания голосования с glassmorphism дизайном
 * 
 * Оптимизирована для mobile:
 * - Glassmorphism & time-based градиенты
 * - Smart presets & live preview
 * - Enhanced визуализация блюд
 * - Progress indicators
 * - Haptic feedback
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Clock, 
  Users, 
  CheckCircle2, 
  Circle,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  Utensils,
  Check,
  Shuffle,
  Loader,
  X,
} from 'lucide-react';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { GlassCard, GlassCardContent, GlassCardHeader } from '../ui/glass-card';
import { Progress } from '../ui/progress';
import { cn } from '@/lib/utils';
import { useAuth } from '@/hooks/useAuth';
import { useHaptic } from '@/hooks/useHaptic';
import { menuService, MenuItem } from '@/services/menu.service';
import { userService, Group } from '@/services/user.service';
import { pollsService } from '@/services/polls.service';

interface CreatePollFormProps {
  onSuccess?: (pollId: number) => void;
  onCancel?: () => void;
  compact?: boolean;
}

export const CreatePollForm: React.FC<CreatePollFormProps> = ({
  onSuccess,
  onCancel,
  compact = true,
}) => {
  const { user } = useAuth();
  const haptic = useHaptic();

  // State
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroupId, setSelectedGroupId] = useState<number | null>(null);
  const [duration, setDuration] = useState(30);
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [selectedItems, setSelectedItems] = useState<Set<number>>(new Set());
  const [showAllItems, setShowAllItems] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>('Все');
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [creationStep, setCreationStep] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Load data
  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [menuResponse, groupsResponse] = await Promise.all([
        menuService.getActiveItems(),
        userService.getUserGroups(),
      ]);

      if (menuResponse.success && menuResponse.data) {
        setMenuItems(menuResponse.data);
        // Auto-select all items by default
        setSelectedItems(new Set(menuResponse.data.map(item => item.id)));
      }

      if (groupsResponse.success && groupsResponse.data) {
        setGroups(groupsResponse.data);
        // Auto-select first group
        if (groupsResponse.data.length > 0) {
          setSelectedGroupId(groupsResponse.data[0].id);
        }
      }
    } catch (err) {
      console.error('Error loading data:', err);
      setError('Ошибка загрузки данных');
    } finally {
      setLoading(false);
    }
  };

  const canCreatePoll = (): boolean => {
    return (
      selectedGroupId !== null &&
      selectedItems.size >= 2 &&
      duration >= 1 &&
      duration <= 1440
    );
  };

  const handleCreate = async () => {
    if (!canCreatePoll()) {
      setError('Заполните все поля корректно');
      haptic.error();
      return;
    }

    try {
      setCreating(true);
      setError(null);

      const response = await pollsService.createPollFromWebApp({
        groupId: selectedGroupId!,
        duration,
        selectedMenuItems: Array.from(selectedItems),
        title: 'Голосование за обед',
      });

      if (response.success && response.data) {
        haptic.success();
        onSuccess?.(response.data.pollId);
      } else {
        throw new Error(response.error || 'Failed to create poll');
      }
    } catch (err: any) {
      console.error('Error creating poll:', err);
      
      let errorMessage = 'Ошибка создания голосования';
      
      // Проверяем разные типы ошибок
      const errorText = err.error || err.message || '';
      
      if (errorText.includes('already has an active poll') || errorText.includes('Group already has active poll')) {
        errorMessage = 'В этой группе уже есть активное голосование. Дождитесь его завершения.';
      } else if (errorText.includes('Not enough items') || errorText.includes('NOT_ENOUGH_ITEMS')) {
        errorMessage = 'Выберите минимум 2 блюда';
      } else if (errorText.includes('Network error') || err.code === 'NETWORK_ERROR') {
        errorMessage = 'Ошибка сети. Проверьте подключение к интернету.';
      } else if (errorText.includes('Access denied') || err.code === 'ACCESS_DENIED') {
        errorMessage = 'Недостаточно прав для создания голосования';
      } else if (err.code === 'INVALID_GROUP') {
        errorMessage = 'Выберите группу';
      } else if (errorText) {
        errorMessage = `Ошибка: ${errorText}`;
      }
      
      setError(errorMessage);
      haptic.error();
    } finally {
      setCreating(false);
    }
  };

  const toggleItem = (itemId: number) => {
    haptic.light();
    const newSelected = new Set(selectedItems);
    if (newSelected.has(itemId)) {
      newSelected.delete(itemId);
    } else {
      newSelected.add(itemId);
    }
    setSelectedItems(newSelected);
  };

  const toggleAll = () => {
    haptic.selection();
    if (selectedItems.size === menuItems.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(menuItems.map(item => item.id)));
    }
  };

  const selectRandom = () => {
    haptic.medium();
    // Используем отфильтрованные блюда (по категории)
    const itemsToSelect = activeCategory === 'Все' ? menuItems : filteredItems;
    // Случайный выбор от 3 до 6 блюд
    const count = Math.floor(Math.random() * 4) + 3;
    const shuffled = [...itemsToSelect].sort(() => Math.random() - 0.5);
    const randomItems = shuffled.slice(0, Math.min(count, itemsToSelect.length));
    setSelectedItems(new Set(randomItems.map(item => item.id)));
  };

  const setQuickDuration = (minutes: number) => {
    haptic.selection();
    setDuration(minutes);
  };

  // Format duration для live preview
  const formatDuration = (minutes: number): string => {
    if (minutes < 60) {
      return `${minutes} мин`;
    } else {
      const hours = Math.floor(minutes / 60);
      const mins = minutes % 60;
      return mins > 0 ? `${hours}ч ${mins}м` : `${hours} час${hours > 1 ? 'а' : ''}`;
    }
  };

  // Получить уникальные категории
  const categories = Array.from(new Set(menuItems.map(item => item.category).filter(Boolean))) as string[];

  // Фильтрованные блюда по категории
  const filteredItems = activeCategory === 'Все' 
    ? menuItems 
    : menuItems.filter(item => item.category === activeCategory);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 bg-white dark:bg-gray-900">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  if (!user?.isAdmin) {
    return (
      <div className="p-6 text-center bg-white dark:bg-gray-900">
        <AlertCircle className="mx-auto mb-4 text-yellow-500" size={48} />
        <p className="text-gray-600 dark:text-gray-400">
          Только администраторы могут запускать голосования
        </p>
      </div>
    );
  }

  // Check if no menu items
  if (menuItems.length === 0) {
    return (
      <div className="p-6 text-center bg-white dark:bg-gray-900">
        <AlertCircle className="mx-auto mb-4 text-orange-500" size={48} />
        <p className="text-gray-900 dark:text-white font-semibold mb-2">
          Меню пустое
        </p>
        <p className="text-gray-600 dark:text-gray-400 mb-4">
          Добавьте блюда в меню перед созданием голосования
        </p>
        {onCancel && (
          <button
            onClick={onCancel}
            className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          >
            Закрыть
          </button>
        )}
      </div>
    );
  }

  // Compact view: show only first 5 items unless expanded
  const visibleItems = compact && !showAllItems 
    ? filteredItems.slice(0, 5) 
    : filteredItems;
  
  const hasMore = compact && filteredItems.length > 5;

  return (
    <div className="relative space-y-0 bg-white dark:bg-gray-900">
      {/* Close Button */}
      {onCancel && (
        <button
          onClick={() => {
            onCancel();
            haptic.light();
          }}
          className="absolute top-4 right-4 z-50 w-10 h-10 rounded-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700 flex items-center justify-center transition-all duration-200 hover:scale-110 shadow-lg"
        >
          <X className="text-gray-700 dark:text-gray-300" size={20} />
        </button>
      )}

      <div className="p-6 pt-16 space-y-5">
      {/* 🎨 Group Selection - GlassCard */}
      {groups.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <GlassCard intensity="medium" hover>
            <GlassCardContent>
              <div className="flex items-center gap-3 mb-3">
                <div className="p-2.5 rounded-xl bg-peach-500/20">
                  <Users className="text-peach-500" size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    Группа
                  </h3>
                  <p className="text-xs text-gray-500">
                    Где запустить голосование
                  </p>
                </div>
              </div>
              
              {/* Группы как радио-кнопки */}
              <div className="space-y-2">
                {groups.map((group, index) => (
                  <motion.button
                    key={group.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.25 + index * 0.05 }}
                    onClick={() => {
                      setSelectedGroupId(group.id);
                      haptic.selection();
                    }}
                    className={cn(
                      "w-full p-3 rounded-xl border-2 transition-all",
                      selectedGroupId === group.id
                        ? "border-peach-500 bg-peach-50 dark:bg-peach-500/10"
                        : "border-gray-200 dark:border-gray-700 hover:border-peach-300 dark:hover:border-peach-700"
                    )}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium text-gray-900 dark:text-white">
                        {group.title}
                      </span>
                      {selectedGroupId === group.id && (
                        <motion.div
                          initial={{ scale: 0, rotate: -180 }}
                          animate={{ scale: 1, rotate: 0 }}
                        >
                          <CheckCircle2 className="text-peach-500" size={20} />
                        </motion.div>
                      )}
                    </div>
                  </motion.button>
                ))}
              </div>
            </GlassCardContent>
          </GlassCard>
        </motion.div>
      )}

      {/* 🎨 Duration - Smart Presets */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <GlassCard intensity="medium" hover>
          <GlassCardContent>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-mint-500/20">
                  <Clock className="text-mint-500" size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 dark:text-white">Длительность голосования</h3>
                </div>
              </div>
              
              {/* Live countdown preview */}
              <motion.div 
                key={duration}
                initial={{ scale: 1.2 }}
                animate={{ scale: 1 }}
                className="px-3 py-1.5 rounded-lg bg-mint-50 dark:bg-mint-500/10"
              >
                <span className="text-sm font-bold text-mint-700 dark:text-mint-400">
                  {formatDuration(duration)}
                </span>
              </motion.div>
            </div>

            {/* Visual time presets с иконками */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {[
                { value: 15, label: 'Быстро', icon: '⚡' },
                { value: 30, label: 'Обед', icon: '🍽️', popular: true },
                { value: 60, label: 'Час', icon: '⏰' },
                { value: 120, label: 'Долго', icon: '☕' }
              ].map((preset) => (
                <motion.button
                  key={preset.value}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => setQuickDuration(preset.value)}
                  className={cn(
                    "relative p-3 rounded-xl border-2 transition-all",
                    duration === preset.value
                      ? "border-mint-500 bg-mint-50 dark:bg-mint-500/10 shadow-lg"
                      : "border-gray-200 dark:border-gray-700 hover:border-mint-300"
                  )}
                >
                  {preset.popular && (
                    <motion.div
                      initial={{ y: -20, opacity: 0 }}
                      animate={{ y: 0, opacity: 1 }}
                      className="absolute -top-2 -right-2 px-2 py-0.5 rounded-full bg-coral-500 text-white text-[10px] font-bold"
                    >
                      ТОП
                    </motion.div>
                  )}
                  
                  <div className="text-2xl mb-1">{preset.icon}</div>
                  <div className="text-xs font-semibold text-gray-700 dark:text-gray-300">
                    {preset.label}
                  </div>
                  <div className="text-[10px] text-gray-500">
                    {preset.value} мин
                  </div>
                </motion.button>
              ))}
            </div>

            {/* Slider для точной настройки */}
            <div>
              <input
                type="range"
                min={5}
                max={240}
                step={5}
                value={duration}
                onChange={(e) => setDuration(Number(e.target.value))}
                className="w-full h-2 rounded-lg appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to right, #5CAE87 0%, #5CAE87 ${(duration / 240) * 100}%, #e5e7eb ${(duration / 240) * 100}%, #e5e7eb 100%)`
                }}
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>5 мин</span>
                <span>4 часа</span>
              </div>
            </div>
          </GlassCardContent>
        </GlassCard>
      </motion.div>

      {/* 🎨 Menu Items Selection - Enhanced */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <GlassCard intensity="medium">
          <GlassCardContent>
            {/* Header с статистикой */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-xl bg-lavender-500/20">
                  <Utensils className="text-lavender-500" size={20} />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">
                    Блюда в голосовании
                  </h3>
                  <motion.p 
                    key={selectedItems.size}
                    initial={{ scale: 1.2 }}
                    animate={{ scale: 1 }}
                    className="text-xs text-gray-500"
                  >
                    Выбрано: <span className="font-bold text-lavender-600 dark:text-lavender-400">
                      {selectedItems.size}
                    </span> из {menuItems.length}
                  </motion.p>
                </div>
              </div>

              {/* Quick actions */}
              <div className="flex gap-2">
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={toggleAll}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium border-2 border-lavender-200 dark:border-lavender-800 text-lavender-700 dark:text-lavender-400 hover:bg-lavender-50 dark:hover:bg-lavender-500/10"
                >
                  {selectedItems.size === menuItems.length ? '✗ Снять' : '✓ Все'}
                </motion.button>
                
                <motion.button
                  whileTap={{ scale: 0.9 }}
                  onClick={selectRandom}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-butter-50 dark:bg-butter-500/10 text-butter-700 dark:text-butter-400 hover:bg-butter-100 dark:hover:bg-butter-500/20 flex items-center gap-1"
                >
                  <Shuffle size={12} />
                  <span>Случайно</span>
                </motion.button>
              </div>
            </div>

            {/* Progress bar визуализация */}
            <div className="mb-4">
              <Progress 
                value={(selectedItems.size / menuItems.length) * 100}
                className="h-2"
              />
            </div>

            {/* Validation hint */}
            <AnimatePresence>
              {selectedItems.size < 2 && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="mb-3 p-2.5 rounded-lg bg-butter-50 dark:bg-butter-500/10 border border-butter-200 dark:border-butter-800"
                >
                  <div className="flex items-start gap-2">
                    <AlertCircle size={16} className="text-butter-600 dark:text-butter-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-butter-700 dark:text-butter-400">
                      Выберите минимум 2 блюда для голосования
                    </p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Категории фильтров */}
            {categories.length > 0 && (
              <div className="flex gap-2 mb-3 overflow-x-auto pb-2 scrollbar-hide">
                {['Все', ...categories].map((cat) => (
                  <motion.button
                    key={cat}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => {
                      setActiveCategory(cat);
                      haptic.selection();
                    }}
                    className={cn(
                      "px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all",
                      activeCategory === cat
                        ? "bg-lavender-500 text-white shadow-lg"
                        : "bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700"
                    )}
                  >
                    {cat}
                  </motion.button>
                ))}
              </div>
            )}

        {/* Items List */}
        <div className="space-y-2 max-h-64 overflow-y-auto">
          {visibleItems.map((item) => {
            const isSelected = selectedItems.has(item.id);
            
            return (
              <motion.button
                key={item.id}
                layout
                onClick={() => toggleItem(item.id)}
                className={cn(
                  "w-full text-left p-3 rounded-lg border-2 transition-all",
                  isSelected
                    ? "border-primary-food-500 bg-primary-food-50 dark:bg-primary-food-900/20"
                    : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
                )}
              >
                <div className="flex items-center gap-3">
                  <div className="flex-shrink-0">
                    {isSelected ? (
                      <CheckCircle2 className="w-5 h-5 text-primary-food-500" />
                    ) : (
                      <Circle className="w-5 h-5 text-gray-300 dark:text-gray-600" />
                    )}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-medium text-gray-900 dark:text-white text-sm truncate">
                      {item.name}
                    </h4>
                    {item.price && (
                      <p className="text-xs font-semibold text-primary-food-700 dark:text-primary-food-400">
                        {item.price} ₽
                      </p>
                    )}
                  </div>

                  {item.imageUrl && (
                    <img
                      src={item.imageUrl}
                      alt={item.name}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>

            {/* Show More Button */}
            {hasMore && (
              <button
                onClick={() => {
                  setShowAllItems(!showAllItems);
                  haptic.light();
                }}
                className="w-full mt-3 py-2 text-sm font-medium text-lavender-600 dark:text-lavender-400 flex items-center justify-center gap-1 hover:underline"
              >
                {showAllItems ? (
                  <>
                    <span>Показать меньше</span>
                    <ChevronUp size={16} />
                  </>
                ) : (
                  <>
                    <span>Показать все ({filteredItems.length - 5} еще)</span>
                    <ChevronDown size={16} />
                  </>
                )}
              </button>
            )}
          </GlassCardContent>
        </GlassCard>
      </motion.div>

        {/* Error Alert - показывается перед кнопками */}
        <AnimatePresence>
          {error && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="p-4 bg-red-50 dark:bg-red-900/20 rounded-xl border-2 border-red-300 dark:border-red-700 shadow-lg"
            >
              <div className="flex items-start gap-3">
                <AlertCircle size={20} className="text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" />
                <p className="text-red-700 dark:text-red-300 text-sm font-medium">{error}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Buttons */}
        <div className="flex gap-3 pt-4 border-t border-gray-200 dark:border-gray-700">
          {onCancel && (
            <button
              onClick={onCancel}
              disabled={creating}
              className="flex-1 px-4 py-3 rounded-lg bg-peach-500 hover:bg-peach-600 text-white font-medium transition-colors disabled:opacity-50 shadow-md"
            >
              Отмена
            </button>
          )}
          
          <motion.button
            whileTap={{ scale: canCreatePoll() ? 0.95 : 1 }}
            onClick={handleCreate}
            disabled={!canCreatePoll() || creating}
            className={cn(
              "flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-lg font-medium transition-all shadow-md",
              canCreatePoll() && !creating
                ? "bg-lavender-500 hover:bg-lavender-600 text-white"
                : "bg-gray-300 dark:bg-gray-700 text-gray-500 dark:text-gray-400 cursor-not-allowed"
            )}
          >
            {creating ? (
              <>
                <LoadingSpinner size="sm" />
                <span>Запуск...</span>
              </>
            ) : (
              <>
                <Check size={18} />
                <span>Запустить</span>
              </>
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
};
