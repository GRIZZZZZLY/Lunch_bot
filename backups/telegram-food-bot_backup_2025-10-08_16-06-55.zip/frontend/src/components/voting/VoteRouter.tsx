import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { pollsService } from '../../services/polls.service';
import { LoadingSpinner } from '../common/LoadingSpinner';
import { logger } from '../../utils/logger';

/**
 * VoteRouter - Умный роутер для страницы голосований
 * 
 * Логика:
 * 1. Проверяет наличие пользователя
 * 2. Запрашивает все активные голосования (backend фильтрует по доступу пользователя)
 * 3. Если есть активные → перенаправляет на первое
 * 4. Если нет → перенаправляет на VotingHubPage (пустое состояние)
 * 
 * ПРИМЕЧАНИЕ: Backend endpoint /polls/active должен возвращать только те голосования,
 * к которым у пользователя есть доступ (его группы)
 */
export const VoteRouter: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    checkActivePolls();
  }, [user]);

  const checkActivePolls = async () => {
    try {
      setChecking(true);
      
      if (!user) {
        console.log('[VoteRouter] No user found, redirecting to hub');
        navigate('/vote/hub', { replace: true });
        return;
      }
      
      console.log('[VoteRouter] Checking active polls for user:', user.id);
      
      // Получаем все активные голосования пользователя
      // Backend должен вернуть только те голосования, к которым у пользователя есть доступ
      const response = await pollsService.getActivePolls();
      
      if (response.success && response.data && response.data.length > 0) {
        const firstPoll = response.data[0];
        
        console.log('[VoteRouter] Found active poll:', {
          pollId: firstPoll.id,
          groupId: firstPoll.groupId,
          status: firstPoll.status,
          totalFound: response.data.length
        });
        
        // Перенаправляем на первое активное голосование
        navigate(`/vote/${firstPoll.id}`, { replace: true });
      } else {
        // Нет активных голосований - показываем hub
        console.log('[VoteRouter] No active polls found, redirecting to hub');
        navigate('/vote/hub', { replace: true });
      }
      
    } catch (error) {
      console.error('[VoteRouter] Error checking active polls:', error);
      logger.error('[VoteRouter] Failed to check active polls', error);
      
      // В случае ошибки перенаправляем на hub
      navigate('/vote/hub', { replace: true });
    } finally {
      setChecking(false);
    }
  };

  // Показываем loader пока проверяем
  if (checking) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white dark:bg-gray-900">
        <div className="text-center">
          <LoadingSpinner size="lg" />
          <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">
            Загрузка голосований...
          </p>
        </div>
      </div>
    );
  }

  // Этот компонент всегда редиректит, поэтому не показываем ничего
  return null;
};
